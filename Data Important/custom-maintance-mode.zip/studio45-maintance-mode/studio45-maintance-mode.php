<?php
/*
Plugin Name:  Studio45 Maintance Mode 
Plugin URI:   https://studio45.in/
Description:  Website is down for Maintance.
Version:      1.0
Author:       Studio45 
Author URI:   https://studio45.in/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  studio45-maintance-mode
Domain Path:  /languages
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function studio45_maintance_register_settings() {
  register_setting( 'studio45_group_maintance', 'studio45-maintance' );
}
add_action( 'admin_init', 'studio45_maintance_register_settings' );

function studio45_settings_page() {
    add_menu_page( 'Maintance Mode Setting', 'Maintance Mode Setting', 'administrator', 'studio45_settings_page', 'studio45_maintance_mode' );	
}
add_action( 'admin_menu', 'studio45_settings_page' );

function studio45_maintance_mode() {
  $options = get_option( 'studio45-maintance' ); ?>
  <style>form.options_form {background: #FFF; padding: 10px 15px;} .form-table td {padding: 10px 10px;}</style>
  <div class="wrap">
    <form method="post" action="options.php" class="options_form">
      <?php settings_fields( 'studio45_group_maintance' ); ?>
      <table class="form-table">
        <tr>
          <th colspan="2" style="padding: 0px 10px 0px 0;"><h3>Maintance Mode Settings</h3></th>
        </tr>   
        <tr valign="top">
            <th scop="row">
                <label for="studio45-maintance[status]"><?php _e( 'Status' ); ?></label>
            </th>
            <td>
                <?php
                $dateyes_arr = ['activated' => 'Activated', 'deactivated' => 'Deactivated'];
                $answerdate = esc_attr( $options['status'] );
                ?>
                <?php foreach($dateyes_arr as $key => $dateyes): ?>
                <label>
                  <input type="radio" name="studio45-maintance[status]" value="<?php echo $key; ?>" <?php  if($answerdate == $key){ echo 'checked';} ?> ><?php echo $dateyes; ?>
                </label>
                <?php endforeach; ?>
            </td>
        </tr>
        <!-- <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_logo]"><?php //_e( 'Logo' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="text" id="studio45-maintance[maintance_logo]" style="width: 400px;" name="studio45-maintance[maintance_logo]" value="<?php //if( isset( $options['maintance_logo'] ) ) { echo esc_attr( $options['maintance_logo'] ); } ?>"/>
          </td>
        </tr> -->
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[profile_picture]"><?php _e( 'File Logo' ); ?></label>
          </th>
          <td>
            <span class="picture_image">
                <?php $profile_picture = $options['profile_picture']; 
                  if(!empty($profile_picture)) {?>
                  <img src="<?php echo $profile_picture; ?>" id="profile-picture1" height="auto" width="200px">
                <?php } ?>  
            </span><br>
            <input type="button" class="button button-secondary" value="Upload Profile Picture" id="upload-button">
            <input type="hidden" id="profile-picture" name="studio45-maintance[profile_picture]" value="<?php if( isset( $options['profile_picture'] ) ) { echo esc_attr( $options['profile_picture'] ); } ?>" />
          </td>
        </tr>
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_title]"><?php _e( 'Title' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="text" id="studio45-maintance[maintance_title]" style="width: 400px;" name="studio45-maintance[maintance_title]" value="<?php if( isset( $options['maintance_title'] ) ) { echo esc_attr( $options['maintance_title'] ); } ?>"/>
          </td>
        </tr>
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_desc]"><?php _e( 'Description' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="text" id="studio45-maintance[maintance_desc]" style="width: 400px;" name="studio45-maintance[maintance_desc]" value="<?php if( isset( $options['maintance_desc'] ) ) { echo esc_attr( $options['maintance_desc'] ); } ?>"/>
          </td>
        </tr>        
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_phone]"><?php _e( 'Enquiry Phone' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="text" id="studio45-maintance[maintance_phone]" style="width: 400px;" name="studio45-maintance[maintance_phone]" value="<?php if( isset( $options['maintance_phone'] ) ) { echo esc_attr( $options['maintance_phone'] ); } ?>"/>
          </td>
        </tr>
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_email]"><?php _e( 'Email' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="email" id="studio45-maintance[maintance_email]" style="width: 400px;" name="studio45-maintance[maintance_email]" value="<?php if( isset( $options['maintance_email'] ) ) { echo esc_attr( $options['maintance_email'] ); } ?>"/>
          </td>
        </tr>
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_bg_img]"><?php _e( 'Background Image' ); ?></label>
          </th>
          <td>
            <span class="bg_image">
                <?php $maintance_bg_img = $options['maintance_bg_img']; 
                  if(!empty($maintance_bg_img)) {?>
                  <img src="<?php echo $maintance_bg_img; ?>" id="bg-picture1" height="auto" width="200px">
                <?php } ?>  
            </span><br>
            <input type="button" class="button" value="Upload BackGround Image" id="bg-upload-button">
            <input type="hidden" id="bg-picture" name="studio45-maintance[maintance_bg_img]" value="<?php if( isset( $options['maintance_bg_img'] ) ) { echo esc_attr( $options['maintance_bg_img'] ); } ?>" />
          </td>
        </tr>
        <tr valign="top">
          <th scop="row">
            <label for="studio45-maintance[maintance_font_color]"><?php _e( 'Font Color' ); ?></label>
          </th>
          <td>
            <input class="regular-text" type="text" id="font-color" style="width: 400px;" name="studio45-maintance[maintance_font_color]" value="<?php if( isset( $options['maintance_font_color'] ) ) { echo esc_attr( $options['maintance_font_color'] ); } ?>"/>
          </td>
        </tr>
      </table>
      <?php submit_button('Update Settings &rarr;'); ?>
    </form>
</div>
<?php }

define( 'MY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MY_PLUGIN_TEMPLATE_DIR', MY_PLUGIN_DIR . '/templates/' );

add_filter( 'template_include', 'ibenic_include_from_plugin', 99 );

function ibenic_include_from_plugin( $template ) {
    $options = get_option( 'studio45-maintance' );

    if($options['status'] == "activated" && !is_user_logged_in() ) {
      $new_template = '';
      $new_template = 'maintance.php';
      
      $plugin_template = MY_PLUGIN_TEMPLATE_DIR . $new_template;
  
      if( file_exists( $plugin_template ) ) {
        return $plugin_template;
      }
    }
      return $template;
}

add_action( 'admin_enqueue_scripts', 'maintance_scripts' );
function maintance_scripts( $hook ){

  wp_register_style( 'custom-style', plugins_url( '/assets/css/custom-style.css',  __FILE__ ));
  wp_enqueue_style( 'custom-style' );

  wp_enqueue_media();

  wp_register_script( 'uploader-script', plugins_url( '/assets/js/uploader.admin.js',  __FILE__ ), array('jquery'), '1.0.0');
  wp_enqueue_script( 'uploader-script' );

  wp_register_script( 'wp-color-picker-alpha', plugins_url( '/assets/js/wp-color-picker-alpha.min.js',  __FILE__ ), array( 'wp-color-picker' ), '1.0.0');
  wp_enqueue_script( 'wp-color-picker-alpha' );
}
