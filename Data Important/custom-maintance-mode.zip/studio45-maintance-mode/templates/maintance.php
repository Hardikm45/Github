<?php
/**
 * Maintenance mode page
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php echo get_bloginfo('name'); ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<meta name="author" content="<?php echo esc_attr( $author ); ?>" />
	</head>
	<body>
		<?php 
		    $options = get_option('studio45-maintance' );
		    $title = $options['maintance_title'];
		    $desc = $options['maintance_desc'];
		    $profile_picture = $options['profile_picture'];
		    $phone = $options['maintance_phone'];
		    $mail = $options['maintance_email'];
		    $bg_img = $options['maintance_bg_img'];
		    $font_color = $options['maintance_font_color'];

		    ?>
		<div class="maintance" align="center" style="background-image:url(<?php echo $bg_img; ?>); background-repeat: no-repeat; background-size: cover; ">
			<div style="padding: 125px; ">
			<div class="head-title"><h1><?php echo get_bloginfo('name'); ?></h1></div>
			<!-- <div>
				<h1>Maintenance mode</h1>
			</div> -->
			<div class="maintance_main" style="color: <?php echo $font_color; ?>; font-family: sans-serif;">
		    <div class="logo">
		    	<a href="<?php echo home_url(); ?>">
		        	<img class="site-title" src="<?php echo $profile_picture; ?>">
		    	</a>
		    </div>
		    <div class="main-content" style="font-size: 1.5rem;">
			    <div class="title">
			    	<h2><?php echo $title; ?></h2>
			    </div>
			    <div class="description">
			    	<?php echo $desc; ?>
			    </div>
			    <div class="phone">
			    	<?php echo $phone; ?>
			    </div>
			    <div class="mail">
			    	<?php echo $mail; ?>
			    </div>
		    </div>
		    </div>
		    </div>
		</div>
	</body>
</html>